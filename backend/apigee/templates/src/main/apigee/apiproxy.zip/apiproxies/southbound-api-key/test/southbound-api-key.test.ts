import { clearWireMockMappings, getApigeeUrl, setupWireMockMapping } from './helpers';
import { TestHelper } from './utils/test-helper';
import axios from 'axios';

describe('Southbound API Key Proxy', () => {
    let testHelper: TestHelper;
    const proxyName = 'southbound-api-key';

    beforeAll(async () => {
        testHelper = new TestHelper({
            organization: 'hybrid',
            environment: 'local',
            username: 'admin',
            password: 'admin',
            baseUrl: `${getApigeeUrl()}`
        });
        await clearWireMockMappings();

        // Deploy the proxy with test parameters
        await testHelper.deployProxy(proxyName, 'southbound-api-key', {
            'target.url': 'http://mock-server:8080/southbound/apiKey',
            'api.key': 'test-api-key',
            'proxy.basepath': '/southbound-api-key'
        });

        await setupWireMockMapping({
            request: {
              url: '/southbound/apiKey',
              method: 'GET',
              headers: {
                'X-API-Key': 'test-api-key'
              }
            },
            response: {
              status: 200,
              body: '{"message": "Success"}',
              headers: {
                'Content-Type': 'application/json'
              }
            }
          });
    });

    afterAll(async () => {
        await testHelper.cleanup();
    });

    it('should add API key to request and forward to target', async () => {
        // Make a request to the proxy
        const response = await axios.get(`${getApigeeUrl()}/southbound-api-key`);

        // Verify the response
        expect(response.status).toBe(200);
        expect(response.data).toBeDefined();
    });
}); 