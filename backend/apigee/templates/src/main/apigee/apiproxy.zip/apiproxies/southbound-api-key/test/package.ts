import * as fs from 'fs';
import * as path from 'path';
import * as manifest from '../manifest.json';

interface Parameter {
    name: string;
    description: string;
    required: boolean;
    default?: string;
}

interface Manifest {
    name: string;
    description: string;
    parameters: Parameter[];
}

function validateParameters(manifest: Manifest, params: Record<string, string>): void {
    for (const param of manifest.parameters) {
        if (param.required && !(param.name in params)) {
            throw new Error(`Missing required parameter: ${param.name}`);
        }
    }
}

function replaceParametersInFile(filePath: string, params: Record<string, string>): void {
    let content = fs.readFileSync(filePath, 'utf-8');
    
    for (const [paramName, paramValue] of Object.entries(params)) {
        content = content.replace(new RegExp(`{${paramName}}`, 'g'), paramValue);
    }
    
    fs.writeFileSync(filePath, content);
}

function processDirectory(srcDir: string, destDir: string, params: Record<string, string>): void {
    const entries = fs.readdirSync(srcDir, { withFileTypes: true });
    
    for (const entry of entries) {
        const srcPath = path.join(srcDir, entry.name);
        const destPath = path.join(destDir, entry.name);
        
        if (entry.isDirectory()) {
            fs.mkdirSync(destPath, { recursive: true });
            processDirectory(srcPath, destPath, params);
        } else {
            fs.copyFileSync(srcPath, destPath);
            if (entry.name.endsWith('.xml')) {
                replaceParametersInFile(destPath, params);
            }
        }
    }
}

export default async function packageProxy(outputZip: string, ...args: string[]): Promise<void> {
    const params: Record<string, string> = {};
    const tempDir = path.join(path.dirname(__dirname), 'temp');
    const apiproxyDir = path.join(path.dirname(__dirname), 'apiproxy');
    const environmentsDir = path.join(path.dirname(__dirname), 'environments');
    
    // Parse parameters from command line
    for (const arg of args) {
        if (!arg.includes('=')) {
            throw new Error(`Invalid parameter format: ${arg}`);
        }
        const [key, ...valueParts] = arg.split('=');
        params[key] = valueParts.join('='); // Join back in case value contains '='
    }
    
    try {
        // Validate parameters
        validateParameters(manifest, params);
        
        // Create temporary directory for processing
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true });
        }
        fs.mkdirSync(tempDir);
        
        // Process apiproxy files
        const tempApiproxyDir = path.join(tempDir, 'apiproxy');
        fs.mkdirSync(tempApiproxyDir);
        processDirectory(apiproxyDir, tempApiproxyDir, params);
        
        // Copy environments directory
        const tempEnvironmentsDir = path.join(tempDir, 'environments');
        fs.mkdirSync(tempEnvironmentsDir);
        processDirectory(environmentsDir, tempEnvironmentsDir, params);
        
        // Create ZIP package
        await new Promise<void>((resolve, reject) => {
            const output = fs.createWriteStream(outputZip);
            const archive = require('archiver')('zip', {
                zlib: { level: 9 }
            });
            
            output.on('close', () => resolve());
            archive.on('error', (err: Error) => reject(err));
            
            archive.pipe(output);
            archive.directory(tempDir, false);
            archive.finalize();
        });
        
        // Cleanup
        fs.rmSync(tempDir, { recursive: true });
        
        console.log(`Successfully created API proxy package: ${outputZip}`);
        
    } catch (error) {
        console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true });
        }
        throw error;
    }
}

if (require.main === module) {
    const args = process.argv.slice(2);
    if (args.length < 1) {
        console.error('Usage: ts-node package.ts <output_zip> [param1=value1 param2=value2 ...]');
        process.exit(1);
    }
    packageProxy(args[0], ...args.slice(1)).catch(error => {
        console.error(error);
        process.exit(1);
    });
} 