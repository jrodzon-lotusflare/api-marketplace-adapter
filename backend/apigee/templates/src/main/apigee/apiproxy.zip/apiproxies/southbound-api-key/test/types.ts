export interface TestEnvironment {
  apigeeUrl: string;
  wiremockUrl: string;
  apigeePort: number;
  wiremockPort: number;
  apigeeHost: string;
  wiremockHost: string;
}

declare global {
  var environment: TestEnvironment;
} 