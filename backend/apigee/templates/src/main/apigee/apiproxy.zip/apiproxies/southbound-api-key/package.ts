import * as fs from 'fs';
import * as path from 'path';
import * as manifest from './manifest.json';

interface Parameter {
    name: string;
    description: string;
    required: boolean;
    default?: string;
}

interface Manifest {
    name: string;
    description: string;
    parameters: Parameter[];
}

function validateParameters(manifest: Manifest, params: Record<string, string>): void {
    for (const param of manifest.parameters) {
        if (param.required && !(param.name in params)) {
            throw new Error(`Missing required parameter: ${param.name}`);
        }
    }
}

function replaceParametersInFile(filePath: string, params: Record<string, string>): void {
    let content = fs.readFileSync(filePath, 'utf-8');
    
    for (const [paramName, paramValue] of Object.entries(params)) {
        content = content.replace(new RegExp(`{${paramName}}`, 'g'), paramValue);
    }
    
    fs.writeFileSync(filePath, content);
}

function processDirectory(sourceDir: string, targetDir: string, params: Record<string, string>): void {
    const files = fs.readdirSync(sourceDir, { recursive: true });
    
    for (const file of files) {
        if (typeof file !== 'string' || file === 'manifest.json' || file.endsWith('.zip')) {
            continue;
        }
        
        const sourcePath = path.join(sourceDir, file);
        const targetPath = path.join(targetDir, file);
        
        // Create target directory if it doesn't exist
        fs.mkdirSync(path.dirname(targetPath), { recursive: true });
        
        // Copy file
        fs.copyFileSync(sourcePath, targetPath);
        
        // Replace parameters in XML files
        if (file.endsWith('.xml')) {
            replaceParametersInFile(targetPath, params);
        }
    }
}

function createZipPackage(sourceDir: string, outputFile: string): void {
    const output = fs.createWriteStream(outputFile);
    const archive = require('archiver')('zip', {
        zlib: { level: 9 }
    });
    
    archive.pipe(output);
    archive.directory(sourceDir, false);
    archive.finalize();
}

export default function packageProxy(outputZip: string, ...args: string[]): void {
    const params: Record<string, string> = {};
    const tempDir = path.join(path.dirname(__dirname), 'temp');
    
    // Parse parameters from command line
    for (const arg of args) {
        if (!arg.includes('=')) {
            throw new Error(`Invalid parameter format: ${arg}`);
        }
        const [key, value] = arg.split('=', 1);
        params[key] = value;
    }
    
    try {
        // Validate parameters
        validateParameters(manifest, params);
        
        // Create temporary directory for processing
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true });
        }
        fs.mkdirSync(tempDir);
        
        // Process files
        processDirectory(path.join(path.dirname(__dirname), 'apiproxy'), tempDir, params);
        
        // Create ZIP package
        createZipPackage(tempDir, outputZip);
        
        // Cleanup
        fs.rmSync(tempDir, { recursive: true });
        
        console.log(`Successfully created API proxy package: ${outputZip}`);
        
    } catch (error) {
        console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true });
        }
        throw error;
    }
}

if (require.main === module) {
    const args = process.argv.slice(2);
    if (args.length < 1) {
        console.error('Usage: ts-node package.ts <output_zip> [param1=value1 param2=value2 ...]');
        process.exit(1);
    }
    packageProxy(args[0], ...args.slice(1));
} 