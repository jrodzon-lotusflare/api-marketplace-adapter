import axios from 'axios';

// Increase timeout for tests that involve container startup
jest.setTimeout(300000);

// Global beforeAll hook to ensure containers are ready
beforeAll(async () => {
  // Wait for WireMock to be ready
  let retries = 5;
  while (retries > 0) {
    try {
      await axios.get(`${global.environment.wiremockUrl}/__admin/health`);
      break;
    } catch (error) {
      retries--;
      if (retries === 0) throw error;
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  // Wait for Apigee Emulator to be ready
  retries = 5;
  while (retries > 0) {
    try {
      await axios.get(`${global.environment.apigeeUrl}/v1/emulator/version`);
      break;
    } catch (error) {
      retries--;
      if (retries === 0) throw error;
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}); 