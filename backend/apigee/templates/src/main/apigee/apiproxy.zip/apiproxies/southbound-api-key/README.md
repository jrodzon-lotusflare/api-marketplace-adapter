# Southbound API Key Proxy Template

This template creates an Apigee API proxy that adds a predefined API key to requests and forwards them to a target endpoint.

## Features

- Adds a predefined API key as an X-API-Key header to each request
- Forwards requests to a configurable target endpoint
- Configurable base path for the proxy endpoint

## Parameters

The following parameters are required:

- `target.url`: The URL of the target endpoint where requests should be forwarded
- `api.key`: The API key that will be added as an X-API-Key header to each request
- `proxy.basepath`: The base path for the API proxy endpoint (defaults to "/southbound-api-key")

## Usage

### Building the Proxy

To build the proxy with your parameters:

```bash
ts-node test/package.ts output.zip target.url=https://api.example.com api.key=your-api-key proxy.basepath=/my-api
```

This will:
1. Validate all required parameters
2. Replace parameters in the proxy configuration
3. Create a ZIP package ready for deployment

### Deploying the Proxy

The generated ZIP file can be deployed to any Apigee environment using the Apigee Management API or the Apigee UI.

## Testing

The template includes a test suite that verifies:
- Parameter validation
- API key header addition
- Request forwarding
- Response handling

To run the tests:

```bash
npm test
```

## Development

This template is part of the Apigee API Proxy Templates project. For more information about the project structure and development guidelines, see the main project README. 