import axios from 'axios';
import * as fs from 'fs';
import * as path from 'path';
import FormData from 'form-data';

export interface DeployOptions {
    organization: string;
    environment: string;
    username: string;
    password: string;
    baseUrl?: string;
}

export class ApigeeDeployer {
    private options: DeployOptions;
    private baseUrl: string;

    constructor(options: DeployOptions) {
        this.options = options;
        this.baseUrl = options.baseUrl || 'http://localhost:8080';
    }

    private async getAuthToken(): Promise<string> {
        const response = await axios.post(`${this.baseUrl}/oauth/token`, 
            `grant_type=password&username=${this.options.username}&password=${this.options.password}&scope=`,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );
        return response.data.access_token;
    }

    async deployProxy(proxyName: string, proxyZipPath: string): Promise<void> {
        const formData = new FormData();
        formData.append('file', fs.createReadStream(proxyZipPath));

        try {
            // Deploy the proxy to the specified environment
            console.log(`Deploying proxy ${proxyName} to ${this.options.environment}`);
            console.log(formData);
            console.log(formData.getHeaders());
            console.log(proxyZipPath);
            console.log(`${this.baseUrl}/v1/emulator/deploy?environment=${this.options.environment}`);
            await axios.post(
                `${this.baseUrl}/v1/emulator/deploy?environment=${this.options.environment}`,
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                }
            );

            console.log(`Successfully deployed proxy ${proxyName} to ${this.options.environment}`);
        } catch (error) {
            if (axios.isAxiosError(error)) {
                throw new Error(`Failed to deploy proxy: ${error.response?.data?.message || error.message}`);
            }
            throw error;
        }
    }

    async undeployProxy(proxyName: string): Promise<void> {
        const token = await this.getAuthToken();

        try {
            // Undeploy from environment
            await axios.delete(
                `${this.baseUrl}/v1/organizations/${this.options.organization}/environments/${this.options.environment}/apis/${proxyName}/revisions/1/deployments`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            // Delete the proxy
            await axios.delete(
                `${this.baseUrl}/v1/organizations/${this.options.organization}/apis/${proxyName}`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            console.log(`Successfully undeployed proxy ${proxyName}`);
        } catch (error) {
            if (axios.isAxiosError(error)) {
                throw new Error(`Failed to undeploy proxy: ${error.response?.data?.message || error.message}`);
            }
            throw error;
        }
    }
} 