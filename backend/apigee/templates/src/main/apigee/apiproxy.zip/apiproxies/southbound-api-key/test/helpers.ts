import axios from 'axios';
import { TestEnvironment } from './types';

export interface WireMockMapping {
  request: {
    url: string;
    method: string;
    headers?: Record<string, string>;
    body?: string;
  };
  response: {
    status: number;
    body: string;
    headers?: Record<string, string>;
  };
}

export function getWireMockAdminUrl(): string {
  return `${global.environment.wiremockUrl}/__admin`;
}

export function getApigeeUrl(): string {
  return global.environment.apigeeUrl;
}

export async function setupWireMockMapping(mapping: WireMockMapping): Promise<void> {
  try {
    await axios.post(`${getWireMockAdminUrl()}/mappings`, mapping);
  } catch (error) {
    console.error('Failed to setup WireMock mapping:', error);
    throw error;
  }
}

export async function clearWireMockMappings(): Promise<void> {
  try {
    await axios.delete(`${getWireMockAdminUrl()}/mappings`);
  } catch (error) {
    console.error('Failed to clear WireMock mappings:', error);
    throw error;
  }
}

export async function getWireMockRequests(): Promise<any[]> {
  try {
    const response = await axios.get(`${getWireMockAdminUrl()}/requests`);
    return response.data.requests;
  } catch (error) {
    console.error('Failed to get WireMock requests:', error);
    throw error;
  }
} 