import { ApigeeDeployer, DeployOptions } from './deploy';
import packageProxy from '../package';
import * as path from 'path';

export class TestHelper {
    private deployer: ApigeeDeployer;
    private deployedProxies: string[] = [];

    constructor(options: DeployOptions) {
        this.deployer = new ApigeeDeployer(options);
    }

    async deployProxy(proxyName: string, templatePath: string, parameters: Record<string, string>): Promise<void> {
        // Create a temporary directory for the built proxy
        const outputZip = path.join(path.dirname(path.dirname(__dirname)), `${proxyName}.zip`);
        
        // Build the proxy with parameters
        await packageProxy(outputZip, ...Object.entries(parameters).map(([key, value]) => `${key}=${value}`));

        // Deploy the proxy
        await this.deployer.deployProxy(proxyName, outputZip);
        this.deployedProxies.push(proxyName);
    }

    async cleanup(): Promise<void> {
        // Undeploy all proxies that were deployed during the test
        for (const proxyName of this.deployedProxies) {
            try {
                await this.deployer.undeployProxy(proxyName);
            } catch (error) {
                console.error(`Failed to undeploy proxy ${proxyName}:`, error);
            }
        }
        this.deployedProxies = [];
    }
} 